1- To be able use the Quick Parts items, copy the Building Blocks.dotx file to the path C:\Users\%UserName%\AppData\Roaming\Microsoft\Document Building Blocks\1033\16

If you don't have any of these files on your computer(\1033\16), create them yourself and put them into it. (Please do not forget to change %UserName% according to your computer username.)

Note: AppData is a hidden folder. You can find it by selecting the show hidden items. (HIDDEN FILES AND FOLDERS IN WINDOWS**)

2 - Open the Thesis Template - v3.2.docx, and write your thesis inside this document.

3 - To insert a new chapter  click on Insert - Quick Parts - Chapter

4 - To insert a new table    click on Insert - Quick Parts - Table

5 - To insert a new figure   click on Insert - Quick Parts - Figure

6 - To insert a new appendix click on Insert - Quick Parts - Appendix


**HIDDEN FILES AND FOLDERS IN WINDOWS

1. Open File Explorer from the taskbar. 

2. Select View > Options > Change folder and search options.

3. Select the View tab and, in Advanced settings, select Show hidden files, folders, and drives and OK.

or visit https://support.microsoft.com/en-us/windows/show-hidden-files-0320fe58-0117-fd59-6851-9b7f9840fdb2


Note: 

Please visit the frequently asked questions page if you encounter any problems:

https://fbe.metu.edu.tr/tr/tez-yazim-sureci


